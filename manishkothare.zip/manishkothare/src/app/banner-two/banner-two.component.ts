import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner-two',
  templateUrl: './banner-two.component.html',
  styleUrls: ['./banner-two.component.css']
})
export class BannerTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
