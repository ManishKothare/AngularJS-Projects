import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-mobile-parts",
  templateUrl: "./mobile-parts.component.html",
  styleUrls: ["./mobile-parts.component.css"]
})
export class MobilePartsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}

  products: any[] = [
    {
      sku: "MN1001",
      name: "Product 1",
      price: 350,
      country: "UK",
      picture: "./assets/images/product-1.jpg",
      stock: 0
    },
    {
      sku: "MN1002",
      name: "Product 2",
      price: 250,
      country: "USA",
      picture: "./assets/images/product-2.jpg",
      stock: 50
    },
    {
      sku: "MN1003",
      name: "Product 3",
      price: 210,
      country: "IND",
      picture: "./assets/images/product-3.jpg",
      stock: 10
    },
    {
      sku: "MN1004",
      name: "Product 4",
      price: 340,
      country: "UK",
      picture: "./assets/images/product-4.jpg",
      stock: 15
    },
    {
      sku: "MN1005",
      name: "Product 5",
      price: 300,
      country: "IND",
      picture: "./assets/images/product-5.jpg",
      stock: 70
    },
    {
      sku: "MN1006",
      name: "Product 6",
      price: 325,
      country: "USA",
      picture: "./assets/images/product-6.jpg",
      stock: 0
    },
    {
      sku: "MN1007",
      name: "Product 7",
      price: 380,
      country: "UK",
      picture: "./assets/images/product-7.jpg",
      stock: 15
    },
    {
      sku: "MN1008",
      name: "Product 8",
      price: 420,
      country: "IND",
      picture: "./assets/images/product-8.jpg",
      stock: 70
    },
    {
      sku: "MN1009",
      name: "Product 8",
      price: 525,
      country: "USA",
      picture: "./assets/images/product-9.jpg",
      stock: 0
    }
  ];

  quantity = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  myClickFunction(event) {
    alert("Button is clicked");
  }
  changeQuantity(event) {
    alert("Changed quantity from the Dropdown");
  }
}
