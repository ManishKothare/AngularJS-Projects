// Sample images used in the demo
module.exports = [
    'http://s7.postimg.org/dbamgegu3/zen8.jpg',
    'http://s21.postimg.org/er8b066p3/zen2.jpg',
    'http://s4.postimg.org/6mbbcgmwd/zen1.jpg',
    'http://s30.postimg.org/x3cgpdtgx/zen3.jpg',
    'http://s21.postimg.org/h1estw95z/zen4.jpg',
    'http://s8.postimg.org/upypfrk8l/zen5.jpg',
    'http://s7.postimg.org/goiv34aez/zen6.jpg',
    'http://s30.postimg.org/n9zuqbgq9/zen7.jpg',
    'http://s12.postimg.org/9kw5b42d9/zen9.jpg',
    'http://s13.postimg.org/vwf92qbl3/zen10.jpg',
    'http://s4.postimg.org/anf2w9rzh/zen11.jpg',
    'http://s17.postimg.org/gpbiwdsu7/zen12.jpg',
    'http://s9.postimg.org/n5uuedw3z/zen13.jpg',
    'http://s9.postimg.org/x6zonp973/zen14.jpg',
    'http://s2.postimg.org/r0vsbv8op/zen15.jpg',
    'http://s21.postimg.org/szu5d0h2f/zen16.jpg',
    'http://s15.postimg.org/xi59nxox7/zen17.jpg',
    'http://s8.postimg.org/zexjdajw5/zen18.jpg',
    'http://s24.postimg.org/st2ukrfz9/zen19.jpg',
    'http://s15.postimg.org/40kb5u63v/zen20.jpg'
];