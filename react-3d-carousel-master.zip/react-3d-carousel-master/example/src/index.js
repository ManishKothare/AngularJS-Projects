var MainView = require('./MainView');

React.render(
    React.createElement(MainView,null),
    document.getElementById('content')
);


